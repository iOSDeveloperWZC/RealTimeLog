//
//  LogAnalyse.h
//  LogAnalyse
//
//  Created by 王宗成 on 2024/4/15.
//

#import <Foundation/Foundation.h>
#import <LogAnalyse/FCLog.h>
//! Project version number for LogAnalyse.
FOUNDATION_EXPORT double LogAnalyseVersionNumber;

//! Project version string for LogAnalyse.
FOUNDATION_EXPORT const unsigned char LogAnalyseVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LogAnalyse/PublicHeader.h>


