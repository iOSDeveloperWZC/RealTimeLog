//
//  FCLog.h
//  LogAnalyse
//
//  Created by 王宗成 on 2024/4/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FCLog : NSObject

+ (instancetype)share;

/// 打开是否需要实时日志
/// - Parameters:
///   - isRealTime: <#isRealTime description#>
///   - host: <#host description#>
///   - port: <#port description#>
-(void)openRealTimeLog:(BOOL)isRealTime host:(NSString *)host port:(NSInteger)port;
/// 写日志
/// - Parameter log: <#log description#>
+(void)write:(NSString *)log;

/// 导出压缩之后的日志文件
+(NSURL *)exportLogFile;

//调用系统分享功能
+(void)share:(NSURL *)fileURL presentViewcontroller:(UIViewController *)presentViewcontroller;

/// 上传文件到后台服务器，如果后需要做其他操作，请自行实现文件上传
/// - Parameters:
///   - server: 服务器地址
///   - fileURL: 文件路径
///   - completionHandler: 响应
+(void)uploadToServer:(NSString *)server fileURL:(NSURL *)fileURL completionHandler:(void (^)(BOOL success,id res))completionHandler;

@end

NS_ASSUME_NONNULL_END
